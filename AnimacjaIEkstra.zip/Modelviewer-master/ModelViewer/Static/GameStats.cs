﻿namespace ModelViewer.Static
{
    public static class GameStats
    {
        public static string Version = "Version 0.6";
    }
}
